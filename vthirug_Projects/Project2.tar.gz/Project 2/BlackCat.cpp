#include<SDL.h>
#include<iostream>
#include <cmath>
#include "BlackCat.h"

const int EYE_RADIUS=40;
const int EAR_RADIUS=60;
BlackCat::BlackCat(SDL_Renderer* rend,SDL_Point cen,SDL_Color col,int width,int height):renderer(rend),center(cen),color(col),WINDOW_WIDTH(width),WINDOW_HEIGHT(height){
			
}

std::ostream& operator<<(std::ostream& out,const BlackCat& cat){
	return out<<"Width-"<<cat.getWidth()<<" Height-"<<cat.getHeight();
}

int BlackCat::getWidth() const{
	return WINDOW_WIDTH;
}

int BlackCat::getHeight() const{
	return WINDOW_HEIGHT;
}

void BlackCat::drawBlackCat(){
	SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
	SDL_Rect body = {center.x+15, center.y-0, 150, 175};
  	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
  	SDL_RenderFillRect( renderer, &body );
	for (int s=0;s<EAR_RADIUS*2;s++){
		for (int r=0;r<EAR_RADIUS*2;r++){
			int dx=EAR_RADIUS-s;
			int dy=EAR_RADIUS-r;
			if ((dx*dx + dy*dy) <= (EAR_RADIUS * EAR_RADIUS)) {
				SDL_SetRenderDrawColor(renderer,0,0,0,255);
				SDL_RenderDrawPoint(renderer, center.x + dx+5, center.y + dy-200);
				SDL_RenderDrawPoint(renderer, center.x + dx+175, center.y + dy-200);
				if((dx*dx + dy*dy) <= ((EYE_RADIUS * EYE_RADIUS)*3)/4){
					SDL_SetRenderDrawColor(renderer, 255, 80, 80,255);
					SDL_RenderDrawPoint(renderer, center.x + dx+5, center.y + dy-200);
					SDL_RenderDrawPoint(renderer, center.x + dx+175, center.y + dy-200);		
				}			
			}			
		}	
	}
	SDL_Rect head = {center.x-35, center.y-200, 250, 200};
  	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
  	SDL_RenderFillRect( renderer, &head );
	
	SDL_Point v1={center.x+75,center.y-90};
	SDL_Point v2={center.x+105,center.y-90};
	SDL_Point v3={center.x+90,center.y-75};
	SDL_SetRenderDrawColor(renderer,255,255,255,255);
	SDL_RenderDrawLine(renderer, v1.x, v1.y, v2.x, v2.y);
	SDL_RenderDrawLine(renderer, v2.x, v2.y, v3.x, v3.y);
	SDL_RenderDrawLine(renderer, v3.x, v3.y, v1.x,v1.y);

	SDL_RenderDrawLine(renderer, v3.x, v3.y, v3.x,v1.y+35);
	SDL_RenderDrawLine(renderer, v3.x, v1.y+35, v3.x+30,v1.y+25);
	SDL_RenderDrawLine(renderer, v3.x, v1.y+35, v3.x-30,v1.y+25);

	
	SDL_RenderDrawLine(renderer, v3.x+20, v3.y+5,v3.x+80,v3.y-30);
	SDL_RenderDrawLine(renderer, v3.x-20, v3.y+5,v3.x-80,v3.y-30);
	SDL_RenderDrawLine(renderer, v3.x+20, v3.y+5,v3.x+80,v3.y-10);
	SDL_RenderDrawLine(renderer, v3.x-20, v3.y+5,v3.x-80,v3.y-10);
	SDL_RenderDrawLine(renderer, v3.x+20, v3.y+5,v3.x+80,v3.y+10);
	SDL_RenderDrawLine(renderer, v3.x-20, v3.y+5,v3.x-80,v3.y+10);

	SDL_Rect tail = {center.x+160, center.y+125, 120, 20};
  	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
  	SDL_RenderFillRect( renderer, &tail );
		
	SDL_Rect tail2 = {center.x+280, center.y+125, 20, 93};
	SDL_RenderFillRect( renderer, &tail2 );

	SDL_Rect leg1 = {center.x+20, center.y+170, 45, 25};
	SDL_RenderFillRect( renderer, &leg1 );
	SDL_Rect leg2 = {center.x+115, center.y+170, 45, 25};
	SDL_RenderFillRect( renderer, &leg2 );
	


	SDL_SetRenderDrawColor(renderer,254,254,20,255);
	for (int w = 0; w < EYE_RADIUS * 2; w++) {
    		for (int h = 0; h < EYE_RADIUS * 2; h++) {
      			int dx = EYE_RADIUS - w;
      			int dy = EYE_RADIUS - h;
      			if ((dx*dx + dy*dy) <= (EYE_RADIUS * EYE_RADIUS)) {
				SDL_SetRenderDrawColor(renderer,254,254,20,255);
				SDL_RenderDrawPoint(renderer, center.x + dx+37, center.y + dy-140);
				SDL_RenderDrawPoint(renderer, center.x + dx+143, center.y + dy-140);
				if((dx*dx + dy*dy) <= ((EYE_RADIUS * EYE_RADIUS)*3)/4){
					SDL_SetRenderDrawColor(renderer,0,0,0,255);
					SDL_RenderDrawPoint(renderer, center.x + dx+37, center.y + dy-140);
					SDL_RenderDrawPoint(renderer, center.x + dx+143, center.y + dy-140);
				}
      			}
    		}
  	}


}
